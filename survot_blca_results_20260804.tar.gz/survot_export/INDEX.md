# SurvOT-Rank BLCA Priority Queue Results Export
## Exported: 2026-08-04

### Directory Structure

```
survot_export/
├── INDEX.md                            # This file
├── configs/                            # YAML configs for all methods
│   ├── distributional_counterfactual_transport_blca.yaml   # v3.3 / v3.8.2
│   ├── intervention_stable_survival_transport_blca.yaml    # v4.0
│   ├── dct_v41_survival_evidence_ledger_blca.yaml          # v4.1
│   ├── archetypal_risk_composition_blca.yaml               # ArcSurv
│   └── archetypal_transport_composition_blca.yaml          # v4.2 ACT-Surv
│
├── v4.0_30ep/                           # IST-Surv 30ep (old queue)
├── v4.0_staged_50ep/                    # IST-Surv 50ep staged (new queue)
├── v4.1_30ep/                           # Evidence Ledger 30ep
├── v4.1_staged_50ep/                    # Evidence Ledger 50ep staged
├── ArcSurv_30ep/                        # ArcSurv 30ep
├── ArcSurv_staged_50ep/                 # ArcSurv 50ep staged
├── v3.8.2_base_50ep/                    # v3.8.2 MGPTR=0 50ep staged
├── v3.8.2_mgptr_50ep/                   # v3.8.2 MGPTR=0.05 50ep staged
├── v3.8.2_30ep/                         # v3.8.2 adaptive_full 30ep
│
├── v4.0_30ep_ist_metrics.csv            # IST audit per epoch
├── v4.0_50ep_ist_metrics.csv
├── v4.1_30ep_audit_metrics.csv          # v4.1 ledger audit per epoch
├── v4.1_50ep_audit_metrics.csv
├── ArcSurv_30ep_archetype_metrics.csv   # ArcSurv archetype per epoch
├── ArcSurv_50ep_archetype_metrics.csv
├── v3.8.2_30ep_metrics.csv              # v3.8.2 MGPTR per epoch
├── v3.8.2_50ep_base_metrics.csv
└── v3.8.2_50ep_mgptr_metrics.csv
```

### Per-method directory contents
Each method directory contains:
- **epoch_curve_fold{1,2,4}.csv** — per-epoch training/val metrics
- **log_start_{k}_end_{k+1}.txt** — training log for each fold
- **split_{N}_results_final.pkl** — final per-patient predictions
- **model_parameters.txt** — model hyperparameters

### Audit metrics CSV columns
- **v4.1**: v41_ledger, v41_wsi_confidence, v41_omic_confidence, v41_survival_consistency, v41_completion, v41_private_uncertainty, v41_objective
- **ArcSurv**: arc_reconstruction, arc_alignment, arc_balance, arc_simplex_volume, arc_rank, arc_composition_entropy, arc_structure_scale, arc_bank_updating
- **v4.0 IST**: ist_completeness_error, ist_marginal_error, ist_reliability, ist_plan_stability, ist_attribution_stability, ist_risk_stability, ist_sinkhorn_batches
- **v3.8.2**: v382_mgptr_nll, v382_mgptr_raw, v382_mgptr_weighted, v382_geometry_risk_spread, v382_total
